$(document).ready(function(){


  function coinrot(){
    $("#coin").animate({
      dummy: 360
    },{
      duration: 800,
      ease: "linear",
      step: function(now,fx){
        now = parseInt(now);
        if(now<=90){
          setTimeout(function(){
            $("#coin_tail").css("z-index",2);
            $("#coin_head").css("z-index",1);
          }, 0);
        }else if(now<=180){
          setTimeout(function(){
            $("#coin_tail").css("z-index",1);
            $("#coin_head").css("z-index",2);
          }, 200);
        }else if(now<=270){
          setTimeout(function(){
            $("#coin_tail").css("z-index",2);
            $("#coin_head").css("z-index",1);
          }, 400);
        }else{
          setTimeout(function(){
            $("#coin_tail").css("z-index",1);
            $("#coin_head").css("z-index",2);
          }, 600);
        }
        $(this).css("transform","rotateY("+now+"deg)");
      },
      complete: function(){
        $(this).css({
          dummy: 0,
          transform: "rotate(0deg)"
        });
        coinrot();
      }
    });
  }

  coinrot();

  $("#btn").click(function(){
    $("#handt").animate({
      left:"-100px"
    },400);

    $("#handt").delay(500).animate({
      left:"250px"
    },400);

    setTimeout(function(){
      $("#coin").stop();
      $("#coin").css("transform","rotateY(0deg)");
      if(Math.random() > 0.5){
        $("#coin").empty();
        $("#coin").append("<img src='images/coin_tail.png' alt='' />");
      }else{
        $("#coin").empty();
        $("#coin").append("<img src='images/coin_head.png' alt='' />");
      }
    },1300);

    $("#handt").delay(500).animate({
      left:"-100px"
    },400);

  });

});