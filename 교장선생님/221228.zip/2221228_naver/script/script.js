$(document).ready(function(){

  $(".chk").click(function(){
    var total = $(".chk").length;
    var chked = $(".chk:checked").length;
    if(total == chked){
      $("#total").prop("checked","checked");
    }else{
      $("#total").prop("checked",false);
    }
  });

  $("#total").click(function(){
    if($(this).is(":checked")){
      $(".chk").prop("checked","checked");
    }else{
      $(".chk").prop("checked",false);
    }
  });

  $("#confirm").click(function(){
    var total = $(".req").length;
    var chked = $(".req:checked").length;
    if(total == chked){
      location.href = "next.html";
    }else{
      alert("필수 요소를 모두 동의해 주세요.");
    }
  });



});





